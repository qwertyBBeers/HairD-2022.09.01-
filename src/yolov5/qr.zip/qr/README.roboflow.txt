
QR Code - v2 2021-12-02 10:41am
==============================

This dataset was exported via roboflow.ai on April 20, 2022 at 5:10 AM GMT

It includes 562 images.
Qrcode are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 512x512 (Stretch)

No image augmentation techniques were applied.


